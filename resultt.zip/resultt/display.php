<?php
    include("session.php");
    require('db.php');

    $name = $_SESSION['username'];
  
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Marks</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 
</head>
<body>


      <form style="text-align: center;">
        <button class="btn btn-outline-success" type="submit"><a href="logout.php">LogOut</a></button>
      </form>

      
<div class="container">
<center><h2>Student Marks</h2>
<?php
  echo "Hi Mr." . $name."!";
  ?>
  <p>Your marks is</p></center>            
  <table class="table" border=2>
    <thead>
      <tr>
        <th>Name</th>
        <th>Class</th>
        <th>Maths</th>
        <th>Physics</th>
        <th>Science</th>
        <th>Total</th>
        <th>Average</th>

      </tr>
    </thead>
    <tbody>

<?php

  $sql="SELECT * FROM student where name = '$name'";

  $query = mysqli_query($con, $sql);

while($row = mysqli_fetch_array($query))
  {  

    ?>
              
    <tr>
     <td> <?php echo $row['name'] ?> </td>
     <td> <?php echo $row['class'] ?> </td>
     <td> <?php echo $row['maths'] ?> </td>
     <td> <?php echo $row['physics'] ?> </td>
     <td> <?php echo $row['science'] ?> </td>
     <td> <?php echo $row['maths']+$row['physics']+ $row['science']?>
     <td> <?php echo ($row['maths']+$row['physics']+ $row['science'])/3?>
    </tr>

    <?php
}
  



?> 


<?php
  $con = mysqli_connect("localhost","root","","trinity");
 
?>

   
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawStuff);

      function drawStuff() {
        var data = new google.visualization.arrayToDataTable([
          ['Subject', 'Marks'],
          ["Maths", 51],
          ["Physics", 54],
          ["Science", 89]
                  ]);

        var options = {
          title: 'Subject Wise Performance',
          width: 500,
          legend: { position: 'left' },
          chart: { title: 'Student Marks'
                   },
          bars: 'vertical', // Required for Material Bar Charts.
          axes: {
            x: {
              3: { side: 'top', label: 'Percentage'} // Top x-axis.
            }
          },
          bar: { groupWidth: "50%" }
        };

        var chart = new google.charts.Bar(document.getElementById('top_x_div'));
        chart.draw(data, options);
      };
    <div id="top_x_div" style="width: 700px; height: 400px;"></div>
  </body>
</html>

