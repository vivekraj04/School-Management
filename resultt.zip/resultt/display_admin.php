<?php
    include("session.php");
    require('db.php');

    
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Marks</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>


      <form style="text-align: center;">
        <button class="btn btn-outline-success" type="submit"><a href="logout.php">LogOut</a></button>
      </form>



<div class="container">
<center><h2>Student Marks</h2>
  <p>Marks of the student is</p></center>            
  <table class="table">
    <thead>
      <tr>
        <th>Name</th>
        <th>Class</th>
        <th>Maths</th>
        <th>Physics</th>
        <th>Science</th>
      </tr>
    </thead>
    <tbody>

<?php

  $sql="SELECT * FROM student ";

  $query = mysqli_query($con, $sql);

while($row = mysqli_fetch_array($query))
  {  

    ?>
              
    <tr>
     <td> <?php echo $row['name'] ?> </td>
     <td> <?php echo $row['class'] ?> </td>
     <td> <?php echo $row['maths'] ?> </td>
     <td> <?php echo $row['physics'] ?> </td>
     <td> <?php echo $row['science'] ?> </td>
    </tr>

    <?php
}
  

?> 
 </tbody>
  </table>
</div>

<div class="container">
<center><h2>Teacher </h2>
  <p>Marks of the Teacher is</p></center>            
  <table class="table">
    <thead>
      <tr>
        <th>Name</th>
        <th>Subject</th>
      </tr>
    </thead>
    <tbody>

<?php

  $sql1 ="SELECT * FROM teacher1";

  $query1 = mysqli_query($con, $sql1);

while($row1 = mysqli_fetch_array($query1))
  {  

    ?>
              
    <tr>
     <td> <?php echo $row1 ['name'] ?> </td>
     <td> <?php echo $row1 ['subject'] ?> </td>
     </tr>

    <?php
}
  

?> 
 </tbody>
  </table>
</div>

</body>
</html>