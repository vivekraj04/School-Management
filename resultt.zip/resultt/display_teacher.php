<?php
 session_start();
 ?>
<?php
$insert = false;
if(isset($_POST['username']))
{

include('db.php');

$username = $_POST['username'] ;
$class = $_POST['class'];
$maths = $_POST['maths'];
$physics = $_POST['physics'];
$science = $_POST['science'];

  

$sql = "INSERT INTO `student`(`name`, `class`, `maths`, `physics`, `science`) VALUES ('$username','$class','$maths','$physics','$science');";
 //echo $sql;
    
if($con->query($sql) == true)
{
   // echo "Successfully inserted";
   $insert = true;
  
}
else
{
    echo "ERROR: $sql <br> $con->error";
     
}
$con->close();
}
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
<img src="tgs.png" class="tgs">
      <div class="container">
      <h2><center>TRINITY GLOBAL SCHOOL</center></h2>
        <h3><center>Please enter the student Marks</center></h3>
              <?php
         if($insert == true)
         {
        echo "<p><center>Thanks for submitting your form</center></p>";
}
$nameErr="";
$classErr="";
$maths="";
$physics="";
$science="";

        if(isset($_POST['enter']))
        {
            if(empty($_POST['name']))
            {
                $nameErr = "Name can not be empty";
            }
          
           
            if(empty($_POST['class']))
            {
                $classErr = "Class can not be empty";
            }
           
            
            if(empty($_POST['maths']))
            {
                $maths = "Entry for maths can not be empty";
            }
            
        
            if(empty($_POST['physics']))
            {
                $physics = "Physics marks can not be empty";    
            }
            if(empty($_POST['science']))
            {
                $science = "Science Marks can not be empty";
            }
        }

        ?>

   
        <form action="display_teacher.php" method="post">  
            <label>Name: </label>
        <input type="text" name="username" id="name" placeholder="name"><span style="color: red"><?php echo $nameErr ;  ?></span><br>
        <label>Class: </label>
        <input type="text" name="class" id="class" placeholder="class"><span style="color: red"><?php echo $classErr;?></span><br>
        <label>Maths:</label>
        <input type="number" name="maths" id="maths" placeholder="maths"><span style="color: red"><?php echo $maths;?></span><br>
        <label>Physics:</label>
        <input type="number" name="physics" id="physics" placeholder="physics"><span style="color: red"><?php echo $physics; ?></span><br>
        <label>Science:</label>
        <input type="number" name="science" id="science" placeholder="science"><span style="color: red"><?php echo $science; ?></span><br> 
        <button class="btn" name='enter'>Enter</button>
        </form>
        <center>If Already Entered!<br>
        Please ignore and Ask student to login and see the result.
        <p><button><a href="index.php">logout</a></button></p></center>
    </div>
    <script src="index.js"></script>

</body>
</html>