<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body><center>
<img src="tgss.png" class="tgss">
    <h1> TRINITY GLOBAL SCHOOL</h1>
    <form class="logo">
    <h3><a href="student_login.php">Student login</a></h3><br>
    <h3><a href="teacher_login.php">Teacher login</a></h3><br>
    <h3><a href="admin_login.php">Admin Login</a>  
</form>
</center>
</body>
</html>