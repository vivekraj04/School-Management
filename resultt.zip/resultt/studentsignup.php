<?php
 session_start();
 include('db.php');

$insert = false;
if(isset($_POST['name']))
{

    $username = $_POST["name"];
    $password = $_POST["password"];
    $cpassword = $_POST["cpassword"];  
   
if($password == $cpassword)
{
    $sql = "INSERT INTO `student` (`name`, `password`) VALUES ('$username', '$password');" ;
       
        if($con->query($sql) == true)
        {
            $err = true;
        }
        else
{
    echo "ERROR: $sql <br> $con->error";
     
}
$con->close();
}
}
?> 
    

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title><link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<img src="tgss.png" class="tgss">

    <center>
    <div class="signup">
    <h1>Good Morning</h1>
    <form action="" method="POST">
        <input type="text" name="username" placeholder="Username"><br><br>
        <input type="password" name="password" placeholder="Password"><br><br>
        <input type="password" name="cpassword" placeholder="Confirm Password"><br><br>
        <input type="submit" name="signup_btn" value= "signup">
</form>
</center>
<center>
    
    <p><button><a href="index.php">logout</a></button></p></center>
</body>
</html>