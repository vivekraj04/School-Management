
<?php
$msg = false;
require('db.php');
session_start();

if (isset($_POST['submit'])) {
    $username = stripslashes($_POST['username']);    
    $username = mysqli_real_escape_string($con, $username);
    $password = stripslashes($_POST['password']);
    $password = mysqli_real_escape_string($con, $password);
    // Check user is exist in the database
    $query    = "SELECT * FROM teacher1 WHERE name='$username' AND password='$password'";
    $result = mysqli_query($con, $query);
    $rows = mysqli_num_rows($result);
    if ($rows == 1) {
        $_SESSION['username'] = $username;
        
        header("Location: display_teacher.php");    
    } else {
        $msg = true; 
    }
} else { 
    
    
}
?>





<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login</title>
        <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<img src="tgss.png" class="tgss">
        <div class = "container">
        <form action="" method="POST">
                <h2>Teacher Login</h2>
                <p><center>Please enter the valid User name and password</center></p>
                User Name:
                <input type="text" name="username" value="" placeholder="Enter the user name">

                Password:
                <input type="password" name="password" value="" placeholder="Enter the Password"><br><br>

                <input type="submit" class="btn" name ="submit">  
                <p> <center>If you have any issue..Please contact administrator.</center></p>     
                <button class="btn btn-outline-success" type="submit"><a href="index.php">Back</a></button>
        </div>
        </form> 
        
</body>
</html>
