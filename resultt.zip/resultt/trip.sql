-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2022 at 12:42 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trip`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(3) NOT NULL,
  `name` varchar(15) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `password`) VALUES
(1, 'vivek', 'vivek1'),
(2, 'raj', 'raj1');

-- --------------------------------------------------------

--
-- Table structure for table `trip`
--

CREATE TABLE `trip` (
  `id` int(15) NOT NULL,
  `name` text NOT NULL,
  `password` int(25) NOT NULL,
  `class` varchar(30) NOT NULL,
  `maths` varchar(3) NOT NULL,
  `physics` varchar(50) NOT NULL,
  `science` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `trip`
--

INSERT INTO `trip` (`id`, `name`, `password`, `class`, `maths`, `physics`, `science`) VALUES
(1, 'vivek', 1234, '78', '0', '52', '78'),
(2, 'shivam', 54321, '85', '0', '98', '54'),
(3, 'Santosh', 0, '0', '0', '0', '0'),
(4, 'fddf', 0, '0', '0', '435', '543'),
(5, 'FDDFDF', 0, '34', '0', '53', '45'),
(6, 'SUBHAM', 0, '58', '0', '95', '45'),
(7, 'SUBHAM', 0, '58', '0', '95', '45'),
(8, 'vivek raj', 0, '87', '0', '45', '55'),
(9, 'vivek raj', 0, '87', '0', '45', '55'),
(10, 'Shivam singh', 0, '85', '0', '78', '55'),
(11, 'Shivam singh', 0, '85', '0', '78', '55'),
(12, 'Shivam singh', 0, '85', '0', '78', '55'),
(13, 'Shivam singh', 0, '85', '0', '78', '55'),
(14, 'Shivam singh', 0, '85', '0', '78', '55'),
(15, 'Shivam singh', 0, '85', '0', '78', '55'),
(16, 'Shivam singh', 0, '85', '0', '78', '55'),
(17, 'Shivam singh', 0, '85', '0', '78', '55'),
(18, 'Shivam singh', 0, '85', '0', '78', '55'),
(19, 'Shivam singh', 0, '85', '0', '78', '55'),
(20, 'Shivam singh', 0, '85', '0', '78', '55'),
(21, 'Shivam singh', 0, '85', '0', '78', '55'),
(22, 'vivek raj', 0, '55', '10', '65', '85'),
(23, 'alquma', 0, '85', '0', '78', '54'),
(24, 'alquma', 0, '0', '0', '0', '0'),
(25, 'alquma', 0, '0', '0', '78', '54'),
(26, 'alquma ahmad', 0, '10', '56', '87', '87'),
(29, 'santosh', 0, '10', '87', '78', '95'),
(30, 'Sima', 0, '12', '40', '50', '45'),
(31, 'Rahul', 0, '10', '52', '54', '89'),
(32, 'Sharan', 0, '10', '54', '87', '89'),
(33, 'fdf', 0, 'dfd', '34', '43', '33'),
(34, 'india', 0, 'sixth', '54', '78', '54'),
(35, 'india', 0, 'sixth', '54', '78', '54'),
(36, 'india', 0, 'sixth', '54', '78', '54'),
(37, 'india', 0, 'sixth', '54', '78', '54'),
(38, 'india', 0, 'sixth', '54', '78', '54'),
(39, 'india', 0, 'sixth', '54', '78', '54'),
(40, 'india', 0, 'sixth', '54', '78', '54'),
(41, 'india', 0, 'sixth', '54', '78', '54'),
(42, 'india', 0, 'sixth', '54', '78', '54'),
(43, 'india', 0, 'sixth', '54', '78', '54'),
(44, 'india', 0, 'sixth', '54', '78', '54'),
(45, 'india', 0, 'sixth', '54', '78', '54'),
(46, 'india', 0, 'sixth', '54', '78', '54'),
(47, 'shiv kumar ', 0, '10th', '78', '54', '78'),
(137, 'afzal', 0, '12th', '87', '98', '98');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trip`
--
ALTER TABLE `trip`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `trip`
--
ALTER TABLE `trip`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
